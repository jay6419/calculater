# CodeClause_Timer_And_Stopwatch
I developed this simple timer and stopwatch project using HTML,CSS and JAVASCRIPT.
